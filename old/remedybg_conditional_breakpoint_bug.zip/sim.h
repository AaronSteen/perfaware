#pragma once

#include <stdio.h>
#include <stdbool.h>
#include <windows.h>
#include <stdint.h>

#define NULLPTR (void *)0
#define NULLCHAR '\0'
#define MAX_STRING_LEN 255
#define REGISTER_NAME_LEN 2

typedef uint8_t u8;
typedef uint16_t u16;
typedef int8_t s8;
typedef int16_t s16;

#define internal static

#define Assert(Expression) if(!Expression) {NULLPTR = 1;}

struct parsed_inst
{
    bool DestFlag;
    bool IsWord;
    u8 Mod;
    u8 Reg;
    u8 RorM;
    s8 Disp8;
    s16 Disp16;
    u8 *Binary;
};

struct istream
{
    LARGE_INTEGER StreamSize;
    u8 *DoNotCrossThisLine;
    u8 *Start;
    int Idx;
};

struct string
{
    SIZE_T Len;
    char String[MAX_STRING_LEN];
    char *Ptr;
};

struct outbuf
{
    char *Start;
    char *Ptr;
    u8 *DoNotCrossThisLine;
};

struct decoded_inst
{
    u8 *Binary;
    int Size;
    u8 OpcodeEnum;
    struct string OperandOne;
    struct string OperandTwo;
};

enum
{
    ADD = 0,
    PUSH = 1,
    POP = 2,
    OR = 3,
    ADC = 4,
    SBB = 5,
    AND = 6,
    ESprefix = 7,
    DAA = 8,
    SUB = 9,
    CSprefix = 10,
    DAS = 11,
    XOR = 12,
    SSprefix = 13,
    AAA = 14,
    CMP = 15,
    DSprefix = 16,
    AAS = 17,
    INC = 18,
    DEC = 19,
    JMP = 20,
    JO = 21,
    JNO = 22,
    JNBorJAEorJNC = 23,
    JBorJNAEorJC = 24,
    JEorJZ = 25,
    JNEorJNZ = 26,
    JBEorJNA = 27,
    JNBEorJA = 28,
    JS = 29,
    JNS = 30,
    JPorJPE = 31,
    JNPorJPO = 32,
    JLorJNGE = 33,
    JNLorJGE = 34,
    JLEorJNG = 35,
    JNLEorJG = 36,
    TEST = 37,
    XCHG = 38,
    MOV = 39,
    LEA = 40,
    NOP = 41,
    CBW = 42,
    CWD = 43,
    CALL = 44,
    WAIT = 45,
    PUSHF = 46,
    POPF = 47,
    SAHF = 48,
    LAHF = 49,
    MOVS = 50,
    CMPS = 51,
    STOS = 52,
    LODS = 53,
    SCAS = 54,
    RET = 55,
    LES = 56,
    LDS = 57,
    /*INT = 58,*/
    INTO = 59,
    IRET = 60,
    ROL = 61,
    ROR = 62,
    RCL = 63,
    RCR = 64,
    SALorSHL = 65,
    SHR = 66,
    SAR = 67,
    AAM = 68,
    AAD = 69,
    XLAT = 70,
    ESC = 71,
    LOOPNEorLOOPNZ = 72,
    LOOPEorLOOPZ = 73,
    LOOP = 74,
    JCXZ = 75,
    /*IN = 76,*/
    /*OUT = 77,*/
    LOCK = 78,
    REPNEorREPNZ = 79,
    REPorREPEorRERZ = 80,
    HLT = 81,
    CMC = 82,
    NOT = 83,
    NEG = 84,
    MUL = 85,
    IMUL = 86,
    DIV = 87,
    IDIV = 88,
    CLC = 89,
    STC = 90,
    CLI = 91,
    STI = 92,
    CLD = 93,
    STD = 94,
    EXTENDED = 95,
    NOTUSED = 99


} opcodes;

enum
{
    // ByteTwo fields
    MOD_FIELD = 0xC0, // 1100 0000
    FLEX_FIELD = 0x38, // 0011 1000, very flexible field
    R_OR_M_FIELD = 0x07, // 0000 0111

    // MOD field
    MEM_MODE_NO_DISP = 0x00,
    MEM_MODE_DISP8 = 0x01,
    MEM_MODE_DISP16 = 0x02,
    REG_MODE = 0x03,

} CommonEnums;

// push
enum
{

    // Push types
				 // [000 reg 110]
        SEG_REG_PUSH = 0x06,     // 0000 0110 (lowest possible value for first byte of segment register push)
				 // 0011 1110 (upper bound of segment register push)
	
				 // [0101 0reg]
	REG_PUSH = 0x50,	 // 0101 0000 (lowest possible value for first byte of register push)
				 // 0101 0111 (upper bound of register push)


				 // [1111 1111] [mod 110 r/m] [disp-lo  ] [disp-hi  ] 
	REG_OR_MEM_PUSH = 0xFF,	 // 1111 1111 (register/memory push always has this as first byte; if on mod field)
	
    // Segment Registers
	CHECK_SEG_REG = 0x18,    // AND with this and shift right 3 to check the seg reg
				 
} PushEnums;
	
// mov
enum
{
    // MOV types
    MEMorREG_TOorFROM_REG = 0x88,
    IMM_TO_REGorMEM = 0xC6,
    IMM_TO_REG = 0xB0,
    MEM_TO_ACCUM = 0xA0,
    ACCUM_TO_MEM = 0xA2,
    REGorMEM_TO_SEGREG = 0x8E,
    SEGREG_TO_REGorMEM = 0x8C,

    // Special case
    DIRECT_ADDRESS = 0x06

} MovEnums;

extern char *MnemonicLUT[100];
extern char *ByteRegLUT[];
extern char *WordRegLUT[];
extern char *SegRegLUT[];
extern char *EffectiveAddressLUT[];
extern u8 OpcodeLUT[];
