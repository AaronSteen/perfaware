RemedyBG Conditional Breakpoint Bug Reproduction
================================================

Summary:
--------
This project demonstrates a bug in RemedyBG where a conditional breakpoint using a valid struct field
(`IStream.Idx == 29`) fails to trigger, despite the expression evaluating correctly in the watch window.

Steps to Reproduce:
-------------------
1. Open RemedyBG and load the sim8086.exe compiled via the provided build.bat
2. Set a conditional breakpoint on the line `IP += DecodedInst.Size;`
   Condition: IStream.Idx == 29
3. Press F5 to start debugging.

Expected:
---------
RemedyBG halts execution when IStream.Idx == 29.

Actual:
-------
RemedyBG continues running. The condition silently fails despite being visible in the watch window.

Build Info:
-----------
- Compile with build.bat (uses /Zi /Od /DEBUG:FULL)
- Verified symbol correctness and recompilation via inserted `1;` line inside the loop.

Contents:
---------
- sim8086.c
- functions.c
- sim.h
- build.bat
