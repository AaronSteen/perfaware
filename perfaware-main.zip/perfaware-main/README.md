Repo for my exercises for Casey Muratori's performance-aware programming course.
